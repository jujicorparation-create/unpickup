package com.nopickup.mod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class NoPickupCommand {

    // Tracks which players have pickup disabled
    public static final Set<UUID> disabledPlayers = new HashSet<>();

    public static void register() {
        // Listen for toggle packets from clients
        ServerPlayNetworking.registerGlobalReceiver(
                NoPickupNetwork.TOGGLE_PACKET_ID,
                (server, player, handler, buf, responseSender) -> {
                    boolean disable = buf.readBoolean();
                    server.execute(() -> {
                        if (disable) {
                            disabledPlayers.add(player.getUuid());
                            NoPickupMod.LOGGER.info("[NoPickup] {} disabled item pickup", player.getName().getString());
                        } else {
                            disabledPlayers.remove(player.getUuid());
                            NoPickupMod.LOGGER.info("[NoPickup] {} enabled item pickup", player.getName().getString());
                        }
                    });
                }
        );
    }

    public static boolean isPickupDisabled(ServerPlayerEntity player) {
        return disabledPlayers.contains(player.getUuid());
    }
}
