package com.nopickup.mod.mixin;

import com.nopickup.mod.NoPickupCommand;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntity.class)
public class ItemPickupMixin {

    /**
     * Cancel item pickup when the player has it disabled.
     * onPlayerCollision is called server-side when a player walks over an item.
     */
    @Inject(method = "onPlayerCollision", at = @At("HEAD"), cancellable = true)
    private void nopickup_cancelPickup(PlayerEntity player, CallbackInfo ci) {
        // Only act on server side
        if (player instanceof ServerPlayerEntity serverPlayer) {
            if (NoPickupCommand.isPickupDisabled(serverPlayer)) {
                ci.cancel(); // Item stays on ground
            }
        }
    }
}
