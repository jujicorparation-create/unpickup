package com.nopickup.mod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NoPickupMod implements ModInitializer {
    public static final String MOD_ID = "nopickup";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Server-side global toggle: true = pickup disabled
    public static boolean pickupDisabled = false;

    @Override
    public void onInitialize() {
        LOGGER.info("NoPickup Mod loaded! Use I/U keybinds to toggle item pickup.");
        NoPickupCommand.register();
    }
}
